 ----------------------------------------------------------------------------
 WMI Explorer  Version 1.16                                          KS-Soft
 ----------------------------------------------------------------------------

 Status:       Free for non-commercial use

 Notice:       This program may not be sold or resold, distributed as a part
               of  any commercial package, used in a commercial environment,
               used  or  distributed  in support of a commercial service, or
               used  or distributed to support any kind of profit-generating
               activity,  even  if  it  is  being distributed freely. If you
               would like to distribute this program as part of a commercial
               distribution,  magazine,  Internet  book, CD ROM, etc. please
               contact us for permission (sales@ks-soft.net).

 Disclaimer:   This program is provided "AS IS" without warranty of any kind
               , either express or implied, including but not limited to the 
               implied  warranties  of  merchantability  and  fitness  for a 
               particular purpose.  In no event  shall the author  be liable 
               for  any  damages  whatsoever   including  direct,  indirect, 
               incidental,   consequential,  loss  of  business  profits  or 
               special damages, even  if  the  author  has  been  advised of
               the possibility of such damages.

 Installation: WMI Explorer does not  require any special installation.  You 
               may unzip/copy the files into any directory.
               However,  if you want to use WMIExplorer  with  Advanced Host
               Monitor, you should  unzip these files  into directory  where
               Advanced Host Monitor is installed.

 Uninstall:    Simply remove the following files
               - wmiexplorer.chm
               - wmiexplorer.exe
               - wmiexplorer.ini
               - readme.txt

 ----------------------------------------------------------------------------
  ���   Copyright (c) 2007-2013 by Alexander Kozlov. All Rights Reserved  ���
 ----------------------------------------------------------------------------
                             sales@ks-soft.net
                            support@ks-soft.net
                              www.ks-soft.net
