#all you need to change here is the ipadress. Example 192.168.2.31. You do not need the <> brackets 


       	Send-TPLinkCommand -Command Reboot -IPAddress <ipadress>